import React from  'react'
export default class NoMatch extends React.Component{
    render(){
        return(
            <div>
                <span>这是404</span>
            </div>
        )
    }
}