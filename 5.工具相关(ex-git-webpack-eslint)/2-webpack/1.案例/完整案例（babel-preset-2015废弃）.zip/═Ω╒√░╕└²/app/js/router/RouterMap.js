import config from '../../json/config.json'
import React from  'react'
import Hello from './../hello'
import Test1 from './../test1'
import Test2 from './../test2'
import NoMatch from './../noMatch'
import '../../css/main.css'
import {
    BrowserRouter as Router,
    Switch,
    Route
} from 'react-router-dom'
export default class RouterMap extends React.Component{
    render(){
        return(
            <Router>
                <div>
                    {config.greetText}
                    <Switch>
                        <Route exact path='/' component={Hello}/>
                        <Route path='/test1' component={Test1}/>
                        {/*如何传递url参数*/}
                        <Route path='/test2/:id' component={Test2}/>
                        {/*404页面配置*/}
                        <Route component={NoMatch}/>
                    </Switch>
                </div>
            </Router>
        )
    }
}