import React from  'react'
import {
    Link
} from 'react-router-dom'
export default class Hello extends React.Component{
    render(){
        return(
            <div>
                <ul>
                    <li><Link to="/test1">test1页面</Link></li>
                    <li><Link to="/test2/3">item2页面</Link></li>
                    <li><Link to="">item3</Link></li>
                </ul>
                <div className="rotate">
                    This is Hello1!!!
                    <span className="small"> </span>
                    <span className="big"> </span>
                </div>
            </div>
        )
    }
}