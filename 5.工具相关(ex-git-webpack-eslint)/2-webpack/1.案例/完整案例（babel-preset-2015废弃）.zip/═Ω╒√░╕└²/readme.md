1. 将index特换为如下代码，可以得到简易版的webpack+react热部署
``` javascript
import config from '../json/config.json'
import React from  'react'
import ReactDom from 'react-dom'
import Hello from './hello'
import '../css/main.css'
export default class Index extends React.Component{
    render(){
        return(
            <div>
                {config.greetText}
                <Hello/>
                <p>asdfasd</p>
                {console.log(PRODUCTION)}
            </div>
        )
    }
}
ReactDom.render(
<Index/>,
    document.getElementById('root')
);
```
1. 实现热部署，react-route基本功能（link转跳，浏览器输入地址转跳，404页面）
2. webpack区分了production模式
3. 学习了webpack基本使用
3. 问题：
	- NODE_ENV并没有起作用，未使用webpack插件定义前端变量，使用后，前端依旧无此值，未解决