import React from  'react'
import ReactDom from 'react-dom'
import RouterMap from './router/RouterMap'
export default class Index extends React.Component{
    render(){
        return(
            <RouterMap/>
        )
    }
}
ReactDom.render(
<Index/>,
    document.getElementById('root')
);