import React from  'react'
export default class Test2 extends React.Component{
    render(){
        return(
            <div>
                <span>这是测试routerTest222222222222222222222</span>
                <span>页面参数为：{this.props.match.params.id}</span>
            </div>
        )
    }
}